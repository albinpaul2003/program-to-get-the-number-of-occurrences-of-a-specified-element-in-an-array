'''
Write a Python program to remove a specified item using the index of an array.
Sample Output:
Original array: array('i', [1, 3, 5, 7, 9])
Remove the third item form the array:
New array: array('i', [1, 3, 7, 9])
'''


array=[]

n=int(input("enter the array length:"))

for i in range(n):
    array.append(int(input("enter the elements:")))
    
print(array)

k=int(input("enter the position of the element to be removed:"))

array.pop(k-1)

print("new array:",array)


















